package com.example.appaid;

import android.Manifest;


import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;

import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

public class MainActivity extends AppCompatActivity {

    private static final String RECIPIENT_PHONE_NUMBER = "6381796016"; // Replace with recipient's phone number

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ImageView shareLocationImageView = findViewById(R.id.shareLocationImageView);
        ImageView menuImageView = findViewById(R.id.secondImageView);
        shareLocationImageView.setOnClickListener(v ->sendLocationSMS());

        menuImageView.setOnClickListener(v -> {
            // Code to navigate to another activity (e.g., LeadActivity)
            Intent intent = new Intent(MainActivity.this, LeadActivity.class);
            startActivity(intent);
        });
    }




    private void sendLocationSMS() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, 1);
        } else {
            sendSMS();
        }
    }

    private void sendSMS() {
        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(MainActivity.RECIPIENT_PHONE_NUMBER, null, "Location is shared", null, null);
            Toast.makeText(getApplicationContext(), "Location is shared", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(getApplicationContext(), "SMS failed, please try again.", Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }
}
