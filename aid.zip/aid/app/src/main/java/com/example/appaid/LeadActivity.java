package com.example.appaid;

import android.os.Bundle;
import android.widget.ImageView;

public class LeadActivity {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    ImageView menuImageView = findViewById(R.id.secondImageView);
}
